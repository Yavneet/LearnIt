import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:math' as math;
import 'provider.dart';
import 'data.dart';

class VocabularyScreen extends StatefulWidget {
  const VocabularyScreen({super.key});
  @override
  State<VocabularyScreen> createState() => _VocabularyScreenState();
}

class _VocabularyScreenState extends State<VocabularyScreen>
    with SingleTickerProviderStateMixin {
  int _currentIndex = 0;
  bool _isFlipped = false;
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _animation = Tween<double>(begin: 0, end: math.pi).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  void _flip() {
    _isFlipped ? _controller.reverse() : _controller.forward();
    setState(() => _isFlipped = !_isFlipped);
  }

  void _next(LearningProvider p) {
    p.markVocabLearned(_currentIndex);
    if (_currentIndex < AppData.words.length - 1) {
      setState(() { _currentIndex++; _isFlipped = false; _controller.reset(); });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('🎉 All flashcards done! Bonus XP awarded!'),
        backgroundColor: Color(0xFF6C63FF),
        behavior: SnackBarBehavior.floating,
      ));
      Navigator.pop(context);
    }
  }

  void _prev() {
    if (_currentIndex > 0) {
      setState(() { _currentIndex--; _isFlipped = false; _controller.reset(); });
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<LearningProvider>();
    final word = AppData.words[_currentIndex];

    return Scaffold(
      backgroundColor: const Color(0xFF0F0E17),
      appBar: AppBar(
        backgroundColor: Colors.transparent, foregroundColor: Colors.white,
        title: Row(
          children: [
            Hero(
              tag: 'icon_Vocabulary',
              child: const Icon(Icons.translate_rounded, color: Color(0xFF6C63FF), size: 24),
            ),
            const SizedBox(width: 10),
            const Text('Vocabulary Flashcards', style: TextStyle(fontSize: 18)),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(child: Text('${_currentIndex + 1}/${AppData.words.length}',
              style: const TextStyle(color: Color(0xFF6C63FF), fontWeight: FontWeight.bold))),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(
              value: (_currentIndex + 1) / AppData.words.length,
              backgroundColor: Colors.white12,
              valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF6C63FF)),
              minHeight: 6,
            ),
          ),
          const SizedBox(height: 8),
          Text('${p.learnedVocab.length} learned · Tap card to flip',
              style: const TextStyle(color: Color(0xFF9E9DB5), fontSize: 12)),
          const SizedBox(height: 30),
          Expanded(
            child: GestureDetector(
              onTap: _flip,
              child: AnimatedBuilder(
                animation: _animation,
                builder: (ctx, _) {
                  final firstHalf = _animation.value < math.pi / 2;
                  return Transform(
                    alignment: Alignment.center,
                    transform: Matrix4.identity()..setEntry(3, 2, 0.001)..rotateY(_animation.value),
                    child: firstHalf
                        ? _CardFace(word: word, isFront: true)
                        : Transform(
                            alignment: Alignment.center,
                            transform: Matrix4.identity()..rotateY(math.pi),
                            child: _CardFace(word: word, isFront: false),
                          ),
                  );
                },
              ),
            ),
          ),
          const SizedBox(height: 24),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _currentIndex > 0 ? _prev : null,
                icon: const Icon(Icons.arrow_back_rounded),
                label: const Text('Previous'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white, side: const BorderSide(color: Colors.white24),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                onPressed: () => _next(p),
                icon: const Icon(Icons.check_rounded),
                label: Text(_currentIndex == AppData.words.length - 1 ? 'Finish (+XP)' : 'Got it! (+10 XP)'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6C63FF), foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ),
          ]),
          const SizedBox(height: 10),
        ]),
      ),
    );
  }
}

class _CardFace extends StatelessWidget {
  final dynamic word;
  final bool isFront;
  const _CardFace({required this.word, required this.isFront});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: isFront
              ? [const Color(0xFF6C63FF), const Color(0xFF3B36CC)]
              : [const Color(0xFF1E1D2E), const Color(0xFF2A2840)],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: const Color(0xFF6C63FF).withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: isFront ? _front() : _back(),
    );
  }

  Widget _front() => Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(20)),
      child: Text(word.category, style: const TextStyle(color: Colors.white70, fontSize: 12)),
    ),
    const SizedBox(height: 20),
    Text(word.word, style: const TextStyle(fontSize: 52, fontWeight: FontWeight.bold, color: Colors.white)),
    const SizedBox(height: 8),
    Text(word.phonetic, style: const TextStyle(fontSize: 18, color: Colors.white70, fontStyle: FontStyle.italic)),
    const SizedBox(height: 30),
    const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(Icons.touch_app_rounded, color: Colors.white54, size: 16),
      SizedBox(width: 6),
      Text('Tap to reveal translation', style: TextStyle(color: Colors.white54, fontSize: 13)),
    ]),
  ]);

  Widget _back() => Padding(
    padding: const EdgeInsets.all(28),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Text('Translation', style: TextStyle(color: Color(0xFF9E9DB5), fontSize: 13)),
      const SizedBox(height: 10),
      Text(word.translation, style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold, color: Color(0xFF6C63FF))),
      const SizedBox(height: 28),
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white.withOpacity(0.05), borderRadius: BorderRadius.circular(12)),
        child: Column(children: [
          const Text('Example', style: TextStyle(color: Color(0xFF9E9DB5), fontSize: 12)),
          const SizedBox(height: 6),
          Text(word.example, textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 15, fontStyle: FontStyle.italic)),
        ]),
      ),
    ]),
  );
}
