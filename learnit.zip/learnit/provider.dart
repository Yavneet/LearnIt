import 'package:flutter/material.dart';
import 'data.dart';
import 'services/firebase_service.dart';

class LearningProvider extends ChangeNotifier {
  int _xp = 0;
  int _streak = 0;
  int _quizScore = 0;
  int _totalQuizAttempts = 0;
  Set<int> _learnedVocab = {};
  Set<int> _learnedGrammar = {};
  List<String> _badges = [];
  
  // SRS / Recommendation Logic
  Map<String, dynamic> _wordErrorRates = {}; 
  Map<String, dynamic> _lastReviewedWord = {};

  final FirebaseService _firebaseService = FirebaseService();

  // Getters
  int get xp => _xp;
  int get level => (_xp / 200).floor() + 1;
  int get xpToNextLevel => 200 - (_xp % 200);
  double get xpProgress => (_xp % 200) / 200.0;
  int get streak => _streak;
  int get quizScore => _quizScore;
  int get totalQuizAttempts => _totalQuizAttempts;
  Set<int> get learnedVocab => _learnedVocab;
  Set<int> get learnedGrammar => _learnedGrammar;
  List<String> get badges => List.unmodifiable(_badges);
  int get vocabTotal => AppData.words.length;
  int get grammarTotal => AppData.grammarRules.length;

  Future<void> loadUserData() async {
    final data = await _firebaseService.getUserData();
    if (data != null) {
      _xp = data['xp'] ?? 0;
      _streak = data['streak'] ?? 0;
      _quizScore = data['quizScore'] ?? 0;
      _totalQuizAttempts = data['totalQuizAttempts'] ?? 0;
      _learnedVocab = Set<int>.from(data['learnedVocab'] ?? []);
      _learnedGrammar = Set<int>.from(data['learnedGrammar'] ?? []);
      _badges = List<String>.from(data['badges'] ?? []);
      _wordErrorRates = data['wordErrorRates'] ?? {};
      _lastReviewedWord = data['lastReviewedWord'] ?? {};
      notifyListeners();
    }
  }

  Future<void> _syncData() async {
    await _firebaseService.updateUserProgress(
      xp: _xp,
      streak: _streak,
      quizScore: _quizScore,
      totalQuizAttempts: _totalQuizAttempts,
      learnedVocab: _learnedVocab.toList(),
      learnedGrammar: _learnedGrammar.toList(),
      badges: _badges,
      wordErrorRates: _wordErrorRates,
      lastReviewedWord: _lastReviewedWord,
    );
  }

  void addXP(int amount) {
    _xp += amount;
    _checkXPBadges();
    _syncData();
    notifyListeners();
  }

  void markVocabLearned(int index) {
    if (_learnedVocab.contains(index)) return;
    _learnedVocab.add(index);
    addXP(10);
    if (_learnedVocab.length == AppData.words.length) {
      _awardBadge('Vocabulary Master 📚');
      addXP(50);
    }
    _syncData();
    notifyListeners();
  }

  void markGrammarLearned(int index) {
    if (_learnedGrammar.contains(index)) return;
    _learnedGrammar.add(index);
    addXP(15);
    if (_learnedGrammar.length == AppData.grammarRules.length) {
      _awardBadge('Grammar Guru 📝');
      addXP(50);
    }
    _syncData();
    notifyListeners();
  }

  void recordQuizAnswer(bool correct, {int? wordIndex}) {
    _totalQuizAttempts++;
    if (correct) {
      _quizScore++;
      addXP(20);
    } else if (wordIndex != null) {
      // Logic for SRS: Track errors
      String key = wordIndex.toString();
      _wordErrorRates[key] = (_wordErrorRates[key] ?? 0) + 1;
    }
    
    if (wordIndex != null) {
      _lastReviewedWord[wordIndex.toString()] = DateTime.now().millisecondsSinceEpoch;
    }

    if (_quizScore >= 5 && !_badges.contains('Quiz Champ 🏆')) {
      _awardBadge('Quiz Champ 🏆');
    }
    _syncData();
    notifyListeners();
  }

  void incrementStreak() {
    _streak++;
    if (_streak == 3) _awardBadge('On Fire! 🔥');
    if (_streak == 7) _awardBadge('Week Warrior ⚔️');
    _syncData();
    notifyListeners();
  }

  void _awardBadge(String badge) {
    if (!_badges.contains(badge)) {
      _badges.add(badge);
    }
  }

  void _checkXPBadges() {
    if (_xp >= 50 && !_badges.contains('XP Earner ⭐')) {
      _awardBadge('XP Earner ⭐');
    }
    if (_xp >= 200 && !_badges.contains('Century Club 💯')) {
      _awardBadge('Century Club 💯');
    }
  }

  // Recommendation Engine Logic
  List<int> getRecommendedVocabIndices() {
    List<MapEntry<String, dynamic>> sortedErrors = _wordErrorRates.entries.toList()
      ..sort((a, b) => (b.value as int).compareTo(a.value as int));
    
    // Top 3 words with highest error rate
    return sortedErrors.take(3).map((e) => int.parse(e.key)).toList();
  }

  Future<void> logout() async {
    await _firebaseService.signOut();
  }
}
